/**
 * PR Review Bot — HTTP entry point.
 *
 * Thin orchestrator that:
 *  1. Receives Bitbucket webhook events
 *  2. Delegates data loading to bitbucket.js
 *  3. Delegates review logic to review-engine.js
 *  4. Delegates comment management back to bitbucket.js
 *  5. Persists final review state via review-engine.js
 */

import * as dotenv from 'dotenv';
dotenv.config();

process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

import express from "express";
import { createLogger } from "./utils.js";

// Bitbucket API layer (comment management service)
import {
  loadPrContext,
  postInlineCommentsForReview,
  upsertReviewComment,
  resolveResolvedComments
} from "./bitbucket.js";

// Review engine (LLM analysis + OpenSearch persistence)
import {
  loadReviewState,
  saveReviewState,
  buildInitialReviewState,
  buildBotStateFromReviewState,
  mergeReviewStateWithResults,
  buildPerFileReviewPrompts,
  runArchitecturalReview,
  runBucketReviews,
  runSingleFileReviews,
  collectLatestIssuesFromFileReviews,
  normalizeIssuesWithLLM,
  buildIssueLifecycle,
  buildNormalizedReviewFromIssues,
  buildIssuesReviewFromList,
  buildAggregateSummaryPrompt,
  buildSummaryCommentText,
  buildIssueKey,
  areIssuesEquivalent
} from "./review-engine.js";

import { pr_summary_schema } from "./llm.schemas.js";
import { queryLLM } from "./utils.js";

const log = createLogger(import.meta.url);

const PORT = process.env.PR_REVIEWER_PORT || 3001;

const BITBUCKET_TOKEN = process.env.BITBUCKET_TOKEN;
if (!BITBUCKET_TOKEN) {
  log.error("BITBUCKET_TOKEN environment variable is not set");
  process.exit(1);
}

const app = express();
app.use(express.json({ limit: "10mb" }));

const PR_EVENTS_SUPPORTED = new Set(["pr:opened", "pr:from_ref_updated"]);

// ---------------------------------------------------------------------------
// Bitbucket PR event handler
// ---------------------------------------------------------------------------

app.post("/bitbucket/pr-event", async (req, res) => {
  try {
    log.info(`Received PR event: ${req.body?.eventKey}`);

    const event = req.body;
    const eventKey = event.eventKey || "unknown_event";

    if (!PR_EVENTS_SUPPORTED.has(eventKey)) {
      log.info(`Ignoring unsupported event key "${eventKey}"`);
      return res.sendStatus(200);
    }

    if (!event.pullRequest) {
      log.warn("No pullRequest object in webhook payload");
      return res.sendStatus(400);
    }

    // -----------------------------------------------------------------------
    // Phase 1: Load PR context from Bitbucket
    // -----------------------------------------------------------------------
    const {
      prId,
      postCommentUrl,
      diff,
      prMeta,
      reviewId,
      reviewState,
      changedFilesDiffs
    } = await loadPrContext({ event });

    // -----------------------------------------------------------------------
    // Phase 2: Initialize or load review state
    // -----------------------------------------------------------------------
    let currentReviewState = reviewState || buildInitialReviewState(prMeta, reviewId, eventKey);

    if (eventKey === "pr:opened" && !reviewState && process.env.PR_REVIEWER_DRYRUN !== "true") {
      await saveReviewState(currentReviewState);
      log.info(`Initialized review state for PR #${prId}`);
    }

    // Extract bot-manageable state from previous review (unresolved issues + summary comment ref)
    const botState = buildBotStateFromReviewState(currentReviewState);

    // FIX (original): was `reviewState.openIssues` (reviewState can be null) and
    // was `buildStateFromReviewState` (wrong function name)
    const previousIssues = eventKey === "pr:from_ref_updated"
      ? botState.unresolvedIssues
      : new Map();

    // Issues from previously open items that are relevant to the now-changed files
    const relatedIssues = (currentReviewState.openIssues || []).filter(openIssue =>
      openIssue.locations.some(loc => Array.from(changedFilesDiffs.keys()).includes(loc.filename))
    );

    // -----------------------------------------------------------------------
    // Phase 3: Build per-file review prompts with semantic context
    // -----------------------------------------------------------------------
    const filePrompts = await buildPerFileReviewPrompts(prMeta, changedFilesDiffs, relatedIssues);

    if (filePrompts.length === 0) {
      log.info(`No reviewable files for PR #${prId} (event: ${eventKey})`);
      return res.sendStatus(200);
    }

    log.info(`Built ${filePrompts.length} per-file review prompts for PR #${prId}`);

    // -----------------------------------------------------------------------
    // Phase 4: Run LLM reviews
    // -----------------------------------------------------------------------

    // Architectural review — determines file grouping (buckets)
    // FIX (original): was `runArchitectureReview` — function is named `runArchitecturalReview`
    const { parsed: architecturalReviewParsed, preface: architecturalReviewPromptPreface } =
      await runArchitecturalReview(prMeta, changedFilesDiffs, prId);

    // Bucket reviews — review grouped related files together
    const bucketReviewResult = await runBucketReviews({
      reviewBuckets: architecturalReviewParsed.review_buckets,
      filePrompts,
      architecturalReviewPromptPreface
    });

    // Single-file reviews — review remaining files individually
    // FIX (original): was `consumedFilepaths` (case mismatch) — should be `consumedFilePaths`
    const singleFileReviewResult = await runSingleFileReviews({
      filePrompts,
      consumedFilePaths: bucketReviewResult.consumedFilePaths,
      architecturalReviewPromptPreface
    });

    const fileReviews = [...bucketReviewResult.fileReviews, ...singleFileReviewResult.fileReviews];
    log.info(`Collected ${fileReviews.length} file reviews for PR #${prId}`);

    // -----------------------------------------------------------------------
    // Phase 5: Normalize issues and build final summary
    // -----------------------------------------------------------------------
    const rawLatestIssues = collectLatestIssuesFromFileReviews(fileReviews);
    log.info(`Raw issues collected: ${rawLatestIssues.length}`);

    const { normalizedIssues, resolvedIssues: overflowResolvedIssues } =
      await normalizeIssuesWithLLM(prMeta, rawLatestIssues);

    const normalizedReview = buildNormalizedReviewFromIssues(normalizedIssues);
    log.info(`Normalized: ${normalizedIssues.length} issues, ${overflowResolvedIssues.length} overflow-resolved`);

    const finalSummaryPrompt = buildAggregateSummaryPrompt(prMeta, [
      { type: "NORMALIZED_ISSUES_REVIEW", filepath: "normalized", review: normalizedReview }
    ]);

    const review = await queryLLM(finalSummaryPrompt, {
      generation_config: {
        responseMimeType: "application/json",
        temperature: 0.7,
        responseSchema: pr_summary_schema
      }
    });

    const reviewParsed = typeof review === "string" ? JSON.parse(review) : review;

    // -----------------------------------------------------------------------
    // Phase 6: Compute issue lifecycle (NEW / OPEN / RESOLVED)
    // -----------------------------------------------------------------------
    const { issueStatuses, newIssues } = buildIssueLifecycle({
      previousIssues,
      latestIssues: normalizedIssues
    });
    log.info(`Issue lifecycle: ${issueStatuses.length} total (${newIssues.length} new)`);

    const reviewToPost = buildSummaryCommentText(
      { ...reviewParsed, potential_issues: normalizedReview.potential_issues },
      issueStatuses
    );

    // -----------------------------------------------------------------------
    // Phase 7: Sync Bitbucket comments (dry-run aware)
    // -----------------------------------------------------------------------
    if (process.env.PR_REVIEWER_DRYRUN === "true") {
      log.info(`[DRY RUN] PR #${prId} review summary:\n${reviewToPost}`);
      await saveReviewState(
        mergeReviewStateWithResults(currentReviewState, {
          eventKey, prMeta, issueStatuses,
          resolvedOverflowIssues: overflowResolvedIssues,
          summaryComment: null
        })
      );
      return res.sendStatus(200);
    }

    // Post new inline comments
    const newlyPostedInlineComments = newIssues.length > 0
      ? await postInlineCommentsForReview({
          url: postCommentUrl,
          review: buildIssuesReviewFromList(newIssues),
          diff
        })
      : [];

    // Resolve comments for issues fixed in this revision
    await resolveResolvedComments({
      url: postCommentUrl,
      previousIssues,
      issueStatuses,
      // FIX (original): was `deleteResoled` (typo) — corrected to `deleteResolved`
      deleteResolved: false
    });

    // Post or update the summary comment
    // FIX (original): was `botState.summaryComment` accessed on undefined `botState`
    const summaryComment = await upsertReviewComment({
      url: postCommentUrl,
      existingComment: botState.summaryComment,
      text: reviewToPost
    });
    log.info(`Upserted summary comment ${summaryComment?.id} for PR #${prId}`);

    // -----------------------------------------------------------------------
    // Phase 8: Persist final review state with comment IDs
    // -----------------------------------------------------------------------
    const postedCommentMap = new Map(
      [...newlyPostedInlineComments]
        .filter(entry => entry?.postedComment?.id)
        .map(entry => [buildIssueKey(entry.issue), entry.postedComment])
    );

    const persistedIssueStatuses = issueStatuses.map(({ issue, status }) => {
      const postedComment = postedCommentMap.get(buildIssueKey(issue));
      const previousEntry = Array.from(previousIssues.values()).find(entry =>
        areIssuesEquivalent(entry.issue, issue)
      );
      return {
        issue: {
          ...issue,
          inlineCommentId: postedComment?.id ?? previousEntry?.id ?? null
        },
        status
      };
    });

    currentReviewState = mergeReviewStateWithResults(currentReviewState, {
      eventKey,
      prMeta,
      issueStatuses: persistedIssueStatuses,
      resolvedOverflowIssues: overflowResolvedIssues,
      summaryComment // FIX (original): was not passed to mergeReviewStateWithResults
    });

    await saveReviewState(currentReviewState);
    log.info(`Saved review state for PR #${prId}`);

    return res.sendStatus(200);
  } catch (err) {
    log.error(`PR handler error: ${err.message}\n${err.stack}`);
    // FIX (original): was `throw err` before `return res.status(500)` making it unreachable
    return res.status(500).send({ error: String(err) });
  }
});

app.listen(PORT, () => log.info(`PR Review Bot listening on :${PORT}`));
