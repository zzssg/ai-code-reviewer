import * as dotenv from 'dotenv';
dotenv.config();

import axios from "axios";
import crypto from "crypto";
import path from "path";
import fs from "fs";
import pino from "pino";
import { fileURLToPath } from "url";
import { Client } from "@opensearch-project/opensearch"; // FIX: was `client` (lowercase)

export const INDEX_NAME = process.env.EMB_INDEX_NAME || "repo-code-embeddings-chunks";
export const PATH_TO_REPO = process.env.EMB_PATH_TO_REPO || "./OpenSearch/";
export const EMB_ENDPOINT = process.env.EMB_ENDPOINT || "http://localhost:1234/v1/embeddings";

export const LLM_REVIEW_MODEL = process.env.LLM_REVIEW_MODEL || "qwen3-coder-30b-a3b-instruct-ud";
export const LLM_ENDPOINT = process.env.LLM_ENDPOINT || "http://localhost:1234/v1/responses"; // FIX: was process.env.EMB_ENDPOINT
export const LLM_API_KEY = process.env.LLM_API_KEY || "";

export const OS_ENDPOINT = process.env.EMB_OS_ENDPOINT || "http://localhost:9200";
export const OS_USER = process.env.EMB_OS_USER;
export const OS_PASS = process.env.EMB_OS_PASS;

if (!OS_USER || !OS_PASS) {
  console.warn("Warning: OpenSearch credentials (EMB_OS_USER, EMB_OS_PASS) are not set.");
  process.exit(1);
}

export const EMB_SIZE_MAP = {
  "qwen3-embedding-0.6b": 1024,
  "embeddingsgma-0.3b": 768,
  "all-MiniLM-L6-v2": 384
};

export function getEmbeddingSize(modelName) {
  return EMB_SIZE_MAP[modelName] || 1024;
}

export const EMB_SIZE = getEmbeddingSize(process.env.EMB_MODEL_NAME || "qwen3-embedding-0.6b");

let osClient = undefined;

export function createLogger(importMetaUrl) {
  const isDev = process.env.NODE_ENV !== "production";
  const filename = path.basename(fileURLToPath(importMetaUrl));

  const logger = pino({
    level: "info",
    timestamp: pino.stdTimeFunctions.isoTime,
    formatters: {
      level(label) {
        return { level: label.toUpperCase() };
      },
      bindings() {
        return {};
      },
      log(obj) {
        return obj;
      }
    },
  }, isDev
    ? pino.transport({
        target: "pino-pretty",
        options: {
          colorize: false,
          translateTime: false,
          messageFormat: `${filename} - {msg}`,
        },
      })
    : undefined
  );

  return logger;
}

export async function embedText(text) {
  const response = await fetch(EMB_ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ input: text }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Embedding request to ${EMB_ENDPOINT} failed: ${response.status} ${errText}`);
  }

  const data = await response.json();

  if (!data.data?.length || !data.data[0].embedding) {
    throw new Error("Invalid response: missing embedding payload");
  }

  return data.data.filter(item => item.object === "embedding").map(item => item.embedding);
}

export function prepareOpenSearchIndexName() {
  const normalized = path.normalize(PATH_TO_REPO).replace(/[\\/]+$/, ""); // FIX: was PATH_NAME_TO_REPO
  const index_suffix = path.basename(normalized).toLowerCase();
  let result = INDEX_NAME;
  if (index_suffix && index_suffix.length > 0) {
    result = INDEX_NAME + "-" + index_suffix;
  }
  return result;
}

export async function ensureIndex(indexName, indexSettingsPath) {
  const { body: exists } = await getOsClient().indices.exists({
    index: indexName,
  });

  if (!exists) {
    const indexBody = JSON.parse(
      fs.readFileSync(indexSettingsPath, "utf-8")
    );
    console.log(`Creating OpenSearch index ${indexName} with body: ${JSON.stringify(indexBody)}`);
    await getOsClient().indices.create({
      index: indexName,
      body: indexBody,
    });
  }
}

export async function searchContext(queryText) {
  const vector = await embedText(queryText);
  const osClient = getOsClient();
  const res = await osClient.search({
    index: INDEX_NAME,
    body: {
      size: 10,
      query: {
        knn: {
          embedding: {
            vector,
            k: 10
          }
        }
      }
    }
  });
  return res.body.hits.hits.map(hit => hit._source);
}

/**
 * Queries the LLM with the given prompt and optional configuration, handling tool calls if needed.
 * Iteratively sends the prompt and tool call results back to the LLM until it returns a final response
 * or exhausts maxToolIterations.
 */
export async function queryLLM(
  prompt,
  {
    generation_config = {},
    safety_settings = [],
    tools = [],
    toolCallback = null,
    maxToolIterations = process.env.LLM_MAX_TOOL_ITERATIONS || 5
  } = {} // FIX: was `} = {} {` — syntax error
) {
  const generationConfig = {
    stopSequences: [],
    temperature: 0.2,
    ...generation_config
  };

  const buildHeaders = () => {
    const headers = { "Content-Type": "application/json" };
    if (LLM_API_KEY.trim() !== "") {
      headers["Authorization"] = `Bearer ${LLM_API_KEY}`;
    }
    return headers;
  };

  const extractText = (candidate) => {
    const parts = candidate?.content?.parts || [];
    return parts
      .filter(part => typeof part?.text === "string" && part.text.trim() !== "") // FIX: was `!part.text.trim() !== ""`
      .map(part => part.text)
      .join("\n")
      .trim();
  };

  const extractToolCalls = (candidate) => {
    const parts = candidate?.content?.parts || [];
    return parts
      .filter(part => part?.functionCall)
      .map(part => ({
        name: part.functionCall.name,
        args: part.functionCall.args || {}
      }));
  };

  const contents = [
    {
      role: "user",
      parts: [{ text: prompt }]
    }
  ];

  const LLM_URL = `${LLM_ENDPOINT}/${LLM_REVIEW_MODEL}:generateContent`;
  console.log(`Using LLM URL: ${LLM_URL}`);

  try {
    for (let iteration = 0; iteration < maxToolIterations; iteration++) {
      const payload = {
        generationConfig,
        safetySettings: safety_settings,
        tools,
        contents
      };

      const llmRawResult = await axios.post(LLM_URL, payload, { headers: buildHeaders() });
      const candidate = llmRawResult.data?.candidates?.[0];

      const toolCalls = extractToolCalls(candidate);
      if (toolCalls.length === 0) {
        const text = extractText(candidate);
        return text || "NO RESPONSE FROM LLM";
      }

      if (typeof toolCallback !== "function") {
        throw new Error("LLM requested a tool call, but no toolCallback was provided");
      }

      for (const toolCall of toolCalls) {
        console.log(`LLM requested tool call: ${toolCall.name} with args: ${JSON.stringify(toolCall.args)}`);
        const toolResult = await toolCallback({
          name: toolCall.name,
          args: toolCall.args
        });
        console.log(`Tool call result: ${JSON.stringify(toolResult)}`);

        contents.push({
          role: "model",
          parts: [{ functionCall: { name: toolCall.name, args: toolCall.args } }]
        });

        contents.push({
          role: "user",
          parts: [{ functionResponse: { name: toolCall.name, response: toolResult ?? {} } }]
        });
      }
    }

    throw new Error(`LLM exceeded max tool iterations: ${maxToolIterations}`); // FIX: was regular string (no interpolation)
  } catch (err) {
    console.error("LLM query failed: ", err);
    return "LLM QUERY FAILED";
  }
}

export function getOsClient() {
  if (!osClient) osClient = new Client({ // FIX: Client is now correctly imported with capital C
    node: OS_ENDPOINT,
    auth: {
      username: OS_USER,
      password: OS_PASS,
    },
    ssl: {
      rejectUnauthorized: false,
    }
  });
  return osClient;
}

export function fileChecksum(text) {
  return crypto.createHash("sha256").update(text, "utf8").digest("hex");
}

export async function runLimited(tasks, limit = 4) {
  const results = [];
  let i = 0;

  async function worker() {
    while (i < tasks.length) {
      const taskIndex = i++;
      results[taskIndex] = await tasks[taskIndex]();
    }
  }

  const workers = Array.from({ length: limit }, worker);
  await Promise.all(workers);

  return results;
}
